using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HZtoPY_HeiSeTouFa
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		/// <summary>
		/// ����תƴ����д
		/// ��ɫͷ��      
		/// C# WinForm Ҫת���ĺ����ַ���     
		/// blog:http://heisetoufa.javaeye.com      
		/// ����:http://www.heisetoufa.cn      
		/// </summary>
		/// <returns>ƴ����д</returns>
	
		public string GetPYString(string str)
		{
			string tempStr = "";
			foreach (char c in str)
			{
				if ((int)c >= 33 && (int)c <= 126)
				{//��ĸ�ͷ���ԭ������           
					tempStr += c.ToString();
				}
				else
				{//�ۼ�ƴ����ĸ     
					tempStr += GetPYChar(c.ToString());
				}
			}
			return tempStr;
		}
		/// <summary>
		/// /// ȡ�����ַ���ƴ����ĸ/// Code By MuseStudio@hotmail.com
		/// /// 2004-11-30/// </summary>/// <param name="c">Ҫת���ĵ�������</param>
		/// /// <returns>ƴ����ĸ</returns>
		public string GetPYChar(string c)
		{
			byte[] array = new byte[2];
			array = System.Text.Encoding.Default.GetBytes(c);
			int i = (short)(array[0] - '\0') * 256 + ((short)(array[1] - '\0'));
			if (i < 0xB0A1) return "*";
			if (i < 0xB0C5) return "a";
			if (i < 0xB2C1) return "b";
			if (i < 0xB4EE) return "c";
			if (i < 0xB6EA) return "d";
			if (i < 0xB7A2) return "e";
			if (i < 0xB8C1) return "f";
			if (i < 0xB9FE) return "g";
			if (i < 0xBBF7) return "h";
			if (i < 0xBFA6) return "g";
			if (i < 0xC0AC) return "k";
			if (i < 0xC2E8) return "l";
			if (i < 0xC4C3) return "m";
			if (i < 0xC5B6) return "n";
			if (i < 0xC5BE) return "o";
			if (i < 0xC6DA) return "p";
			if (i < 0xC8BB) return "q";
			if (i < 0xC8F6) return "r";
			if (i < 0xCBFA) return "s";
			if (i < 0xCDDA) return "t";
			if (i < 0xCEF4) return "w";
			if (i < 0xD1B9) return "x";
			if (i < 0xD4D1) return "y";
			if (i < 0xD7FA) return "z";
			return "*";
		}

		

		private void button1_Click_1(object sender, EventArgs e)
		{
			label1.Text = textBox1.Text + "��ƴ����дΪ��" + this.GetPYString(textBox1.Text);
		}

		private void toolStripStatusLabel2_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://heisetoufa.javaeye.com");     
		} 
	}
}